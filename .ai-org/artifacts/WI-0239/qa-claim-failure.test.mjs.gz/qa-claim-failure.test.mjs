import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fixture, createFixturePool, itemState } from '/Users/zsz1210/Documents/ChatGPT/temple-ai-dev-org/test/helpers/lean-delivery-fixture.mjs';

test('independent QA: real claim denial cleans fresh and pooled allocations without poisoning seed', async t => {
  const pool = createFixturePool();
  t.after(() => pool.cleanup());
  const initial = await pool.fixture(); t.after(initial.cleanup);
  const initialItem = await itemState(initial);
  const seedItemPath = path.join(initial.setup[0].source_target, '.ai-org/work-items/WI-0001.json');
  const seedBefore = await fs.readFile(seedItemPath);
  assert.equal(JSON.parse(seedBefore).claim, null);
  const originalCopy = fs.cp, originalMkdtemp = fs.mkdtemp, originalRead = fs.readFile;
  const pooledCreated = [];
  try {
    fs.mkdtemp = async (...args) => { const p = await originalMkdtemp(...args); pooledCreated.push(p); return p; };
    fs.cp = async (source, destination, options) => {
      await originalCopy(source, destination, options);
      const itemPath = path.join(destination, 'project/.ai-org/work-items/WI-0001.json');
      const item = JSON.parse(await originalRead(itemPath));
      item.claim = structuredClone(initialItem.claim);
      item.claims = [structuredClone(initialItem.claim)];
      await fs.writeFile(itemPath, JSON.stringify(item));
    };
    await assert.rejects(pool.fixture(), /already claimed/);
  } finally { fs.cp = originalCopy; fs.mkdtemp = originalMkdtemp; }
  assert.equal(pooledCreated.length, 1);
  await assert.rejects(fs.stat(pooledCreated[0]), { code: 'ENOENT' });
  assert.deepEqual(await fs.readFile(seedItemPath), seedBefore);
  assert.deepEqual(await itemState(initial), initialItem);
  const recovered = await pool.fixture(); t.after(recovered.cleanup);
  assert.notEqual(recovered.request.claimId, initial.request.claimId);
  assert.equal((await itemState(recovered)).claim.status, 'active');
  assert.equal(recovered.setup[0].source_target, initial.setup[0].source_target);

  const freshCreated = [];
  try {
    fs.mkdtemp = async (...args) => { const p = await originalMkdtemp(...args); freshCreated.push(p); return p; };
    fs.readFile = async (filename, ...args) => {
      const bytes = await originalRead(filename, ...args);
      if (String(filename).endsWith('/.ai-org/project/assignments.json')) {
        const assignments = JSON.parse(bytes);
        assignments.assignments.find(entry => entry.position_id === 'developer').agent_id = 'qa-nonexistent-agent';
        return Buffer.from(JSON.stringify(assignments));
      }
      return bytes;
    };
    await assert.rejects(fixture(), /Unknown Agent Identity: qa-nonexistent-agent/);
  } finally { fs.readFile = originalRead; fs.mkdtemp = originalMkdtemp; }
  assert.equal(freshCreated.length, 1);
  await assert.rejects(fs.stat(freshCreated[0]), { code: 'ENOENT' });
  assert.deepEqual(await fs.readFile(seedItemPath), seedBefore);
});
