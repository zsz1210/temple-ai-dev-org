import fs from 'node:fs';
import {syncBuiltinESMExports} from 'node:module';
if(process.argv.some(arg=>arg.endsWith('optional-console-collector.test.mjs'))) {
  const original=fs.watch;
  let readyAt=0,dropped=0,delivered=0;
  fs.watch=function(target,options,callback){
    readyAt ||= performance.now()+400;
    return original(target,options,(...args)=>{
      if(performance.now()<readyAt){dropped++;return;}
      delivered++;callback(...args);
    });
  };
  syncBuiltinESMExports();
  process.on('exit',()=>console.error('DELAYED_WATCH',JSON.stringify({startup_ms:400,dropped,delivered})));
}
