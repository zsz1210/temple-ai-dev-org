import fs from 'node:fs';
import fsp from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
const root=await fsp.mkdtemp(path.join(os.tmpdir(),'wi0242-native-startup-'));
const results=[];
try {
  for(let i=0;i<24;i++) {
    const directory=path.join(root,String(i));
    await fsp.mkdir(directory);
    const file=path.join(directory,'state');
    await fsp.writeFile(file,'before');
    let eventAt=null;
    const start=performance.now();
    const watcher=fs.watch(directory,()=>{eventAt??=performance.now()-start;});
    try {
      fs.writeFileSync(file,'after');
      await new Promise(r=>setTimeout(r,150));
      if(eventAt===null)await new Promise(r=>setTimeout(r,1500));
      const initial=eventAt;
      if(initial===null){fs.writeFileSync(file,'later');await new Promise(r=>setTimeout(r,300));}
      results.push({sample:i,first_event_ms:initial,later_write_recovered:initial===null&&eventAt!==null});
    } finally {watcher.close();}
  }
} finally {await fsp.rm(root,{recursive:true,force:true});}
console.log(JSON.stringify({node:process.version,uv:process.versions.uv,samples:results.length,missing:results.filter(r=>r.first_event_ms===null).length,results},null,2));
