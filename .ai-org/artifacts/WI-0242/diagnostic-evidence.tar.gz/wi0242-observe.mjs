import fs from 'node:fs';
import http from 'node:http';
import { syncBuiltinESMExports } from 'node:module';
if (process.argv.some(arg => arg.endsWith('/optional-console-collector.test.mjs') || arg === 'test/optional-console-collector.test.mjs')) {
const events = [];
const record = (type, fields = {}) => events.push({at: Math.round(performance.now()), type, ...fields});
const watch = fs.watch;
fs.watch = function(target, options, callback) {
  try {
    const result = watch(target, options, (...args) => {
      record('watch-event', {directory: String(target).split('/').at(-1), event: args[0], file: String(args[1])});
      callback(...args);
    });
    record('watch-attached', {directory: String(target).split('/').at(-1)});
    result.on('error', e => record('watch-error', {code:e.code}));
    return result;
  } catch(e) {record('watch-throw', {code:e.code});throw e;}
};
const createServer = http.createServer;
http.createServer = function(handler) {
  return createServer((req,res) => {
    if(req.url === '/api/v1/events') {
      record('sse-request');
      req.on('close',()=>record('request-close'));
      res.on('close',()=>record('response-close'));
      const write=res.write;
      res.write=function(chunk,...rest){record('sse-write',{chunk:String(chunk).trim()});return write.call(this,chunk,...rest);};
    }
    return handler(req,res);
  });
};
syncBuiltinESMExports();
process.on('exit',()=>console.error('DIAGNOSTIC',JSON.stringify(events)));
}
