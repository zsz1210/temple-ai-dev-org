import fs from 'node:fs';
import {syncBuiltinESMExports} from 'node:module';
if(process.argv.some(arg=>arg.endsWith('optional-console-collector.test.mjs'))) {
  const original=fs.watch;let dropped=0,forwarded=0;
  fs.watch=function(target,options,callback){
    return original(target,options,(event,name)=>{
      if(String(name)==='project.json'){dropped++;return;}
      forwarded++;callback(event,name);
    });
  };
  syncBuiltinESMExports();
  process.on('exit',()=>console.error('QA_DROP_PROJECT',JSON.stringify({dropped,forwarded})));
}
