import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import vm from 'node:vm';
import {setTimeout as delay} from 'node:timers/promises';
import {createHash} from 'node:crypto';

const source=await fs.readFile('test/optional-console-collector.test.mjs','utf8');
const start=source.indexOf('async function* refreshEvents(');
const end=source.indexOf('\ntest(',start);
const exactHelpers=source.slice(start,end);
let cases=0;
function helpers(writeFile=async()=>{}) {
  return vm.runInNewContext(`${exactHelpers}\n({refreshEvents,establishRefreshDelivery})`,
    {assert,TextDecoder,AbortController,AbortSignal,path,fs:{writeFile},delay,JSON,Error});
}
async function* chunks(parts){for(const part of parts)yield part;}
const encoder=new TextEncoder();
const frame=(n)=>`id: ${n}\nevent: temple.refresh\ndata: {"revision":${n},"label":"中文"}\n\n`;
for(const pieces of [[encoder.encode(frame(1)+frame(2))],[...encoder.encode(': comment\n\n'+frame(1)+frame(2))].map(n=>Uint8Array.of(n))]) {
  const events=helpers().refreshEvents(chunks(pieces));
  for(const n of [1,2]) { const {value}=await events.next(); assert.equal(value.revision,n);assert.equal(value.label,'中文'); }
  await assert.rejects(events.next(),/stream ended/);cases++;
}
for(const payload of ['event: temple.refresh\n\n','event: temple.refresh\ndata: bad-json\n\n']) {
  await assert.rejects(helpers().refreshEvents(chunks([encoder.encode(payload)])).next());cases++;
}
{
  let writes=0;
  const h=helpers(async()=>{writes++;});
  const signal=new AbortController().signal;
  const result=await h.establishRefreshDelivery('/fixture',{next:async()=>{await delay(65);return {value:{revision:1}};}},signal);
  assert.equal(result.value.revision,1);assert.ok(writes>=1);
  const stopped=writes;await delay(65);assert.equal(writes,stopped);cases++;
}
{
  const expected=Object.assign(new Error('write denied'),{code:'EACCES'});
  await assert.rejects(helpers(async()=>{throw expected;}).establishRefreshDelivery('/fixture',{next:()=>new Promise(()=>{})},new AbortController().signal),e=>e===expected);cases++;
}
{
  let writes=0;const c=new AbortController();
  const task=helpers(async()=>{writes++;}).establishRefreshDelivery('/fixture',{next:()=>new Promise(()=>{})},c.signal);
  await delay(35);c.abort();await assert.rejects(task,e=>e.name==='AbortError');
  const stopped=writes;await delay(65);assert.equal(writes,stopped);cases++;
}
{
  let writes=0;const expected=new Error('read failed');
  await assert.rejects(helpers(async()=>{writes++;}).establishRefreshDelivery('/fixture',{next:async()=>{await delay(35);throw expected;}},new AbortController().signal),e=>e===expected);
  const stopped=writes;await delay(65);assert.equal(writes,stopped);cases++;
}
console.log(JSON.stringify({candidate:'f1629909739eb08b4616e39d68065da74d29f5d2',exactHelperSha256:createHash('sha256').update(exactHelpers).digest('hex'),passed:cases}));
