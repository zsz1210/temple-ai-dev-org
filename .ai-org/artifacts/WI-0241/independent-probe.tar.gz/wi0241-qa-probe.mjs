import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { validateProjectSchemas as baseline } from '/tmp/wi0241-baseline-schema-validation.mjs';
import { validateProjectSchemas as candidate } from '/Users/REDACTED/Documents/ChatGPT/temple-ai-dev-org/src/schema-validation.mjs';

const repo = '/Users/REDACTED/Documents/ChatGPT/temple-ai-dev-org';
const expected = 'bcafc86e27b59207b0ec5ae78c5089e5c3c86b87';
assert.equal(execFileSync('git', ['rev-parse', 'HEAD'], { cwd: repo, encoding: 'utf8' }).trim(), expected);
assert.equal(execFileSync('git', ['diff', expected, '--', 'src/schema-validation.mjs'], { cwd: repo, encoding: 'utf8' }), '');
const original = execFileSync('git', ['show', 'd3892f6b018c006c28d6cf13590548fed9561f53:src/schema-validation.mjs'], { cwd: repo, encoding: 'utf8' });
const translated = original.replaceAll('"ajv/dist/2020.js"', `"${repo}/node_modules/ajv/dist/2020.js"`).replaceAll('"ajv-formats"', `"${repo}/node_modules/ajv-formats/dist/index.js"`).replaceAll('from "./', `from "${repo}/src/`);
assert.equal(await fs.readFile('/tmp/wi0241-baseline-schema-validation.mjs', 'utf8'), translated);
const D = 'https://json-schema.org/draft/2020-12/schema';
const S = extra => ({ $schema: D, $id: 'https://qa.invalid/schema', ...extra });
const cases = [
  ['root-anchor-integer', S({ $anchor: 'item', type: 'integer', $ref: '#item' }), 7],
  ['root-anchor-string', S({ $anchor: 'item', type: 'string' }), 7],
  ['nested-anchor', S({ $defs: { x: { $anchor: 'item', type: 'string' } }, $ref: '#item' }), 7],
  ['missing-anchor-after-existing', S({ $ref: '#item' }), 7],
  ['duplicate-anchor-failure', S({ $defs: { x: { $anchor: 'dup' }, y: { $anchor: 'dup' } } }), 7],
  ['valid-after-anchor-failure', S({ type: 'integer' }), 7],
  ['dynamic-tree', S({ $dynamicAnchor: 'node', type: 'object', properties: { next: { $dynamicRef: '#node' } } }), { next: { next: 2 } }],
  ['dynamic-tree-changed', S({ $dynamicAnchor: 'node', type: 'array', items: { $dynamicRef: '#node' } }), [[]]],
  ['nested-id', S({ $defs: { x: { $id: 'child', $anchor: 'entry', type: 'number' } }, $ref: 'child#entry' }), 'bad'],
  ['external-after-nested', S({ $ref: 'child#entry' }), 'bad'],
  ['absolute-provider', S({ $id: 'https://qa.invalid/provider', type: 'number' }), 2],
  ['absolute-consumer', S({ $ref: 'https://qa.invalid/provider' }), 2],
  ['empty-id-local', S({ $id: '', $defs: { x: { type: 'string' } }, $ref: '#/$defs/x' }), 2],
  ['fragment-id', S({ $id: '#local', type: 'string' }), 2],
  ['meta-id', S({ $id: D, type: 'string' }), 2],
  ['meta-alias', { $schema: 'http://json-schema.org/schema#', type: 'string' }, 2],
  ['meta-alias-https', { $schema: 'https://json-schema.org/schema', type: 'string' }, 2],
  ['default-dialect', { type: 'string' }, 2],
  ['nested-other-dialect', S({ $defs: { x: { $schema: 'https://invalid.example/schema', type: 'integer' } }, $ref: '#/$defs/x' }), 2],
  ['unknown-meta', S({ $schema: 'https://invalid.example/schema' }), 2],
  ['invalid-type', S({ type: 'bad' }), 2],
  ['valid-after-invalid-type', S({ type: 'number', minimum: 3 }), 2],
  ['invalid-regex', S({ type: 'string', pattern: '[' }), 'x'],
  ['valid-regex-after-failure', S({ type: 'string', pattern: '^y$' }), 'x'],
  ['invalid-schema-root', null, 2],
  ['boolean-false', false, 2],
  ['boolean-true', true, 2],
  ['email-format', S({ type: 'string', format: 'email' }), 'bad'],
  ['unevaluated', S({ type: 'object', anyOf: [{ properties: { a: { type: 'number' } }, required: ['a'] }], unevaluatedProperties: false }), { a: 1, z: 2 }],
  ['recursive-unknown', S({ $recursiveRef: '#', type: 'number' }), 'bad'],
  ['annotation-nested-id', S({ examples: [{ $id: 'example' }], type: 'string' }), 2],
  ['annotation-external-ref', S({ examples: [{ $ref: 'external' }], type: 'string' }), 2],
  ['noncanonical-meta-id', S({ $id: 'https://json-schema.org:443/draft/2020-12/schema', type: 'string' }), 2],
  ['after-noncanonical-meta', S({ type: 'integer' }), 2],
];
const roots = [];
async function write(root, file, value) { await fs.mkdir(path.dirname(path.join(root, file)), { recursive: true }); await fs.writeFile(path.join(root, file), JSON.stringify(value)); }
async function set(root, rows) {
  await write(root, '.ai-org/learning/index.json', { schema_version: 'ai-org.learning-index/v2', entries: [] });
  await write(root, '.ai-org/core/schemas/schema-catalog.json', { schema_version: 'temple.schema-catalog/v1', documents: rows.map((c, i) => ({ id: `probe-${i}`, schema: `${i}.json`, path: `data/${i}.json`, required: true })) });
  for (const [i, c] of rows.entries()) { await write(root, `.ai-org/core/schemas/${i}.json`, c[1]); await write(root, `data/${i}.json`, c[2]); }
}
async function root(rows) { const r = await fs.mkdtemp(path.join(os.tmpdir(), 'wi0241-qa-')); roots.push(r); await set(r, rows); return r; }
function normalize(r) { const { generated_at, ...rest } = r; return rest; }
const observations = [];
async function compare(r, label) {
  const a = normalize(await baseline(r)), b = normalize(await candidate(r));
  assert.deepEqual(b, a, label);
  observations.push({ label, schemas: b.schemas_checked, documents: b.documents_checked, valid: b.valid, errors: b.errors.length, digest: createHash('sha256').update(JSON.stringify(b)).digest('hex') });
}
try {
  const a = await root(cases), b = await root([...cases].reverse());
  await compare(a, 'forward adversarial catalog');
  await compare(b, 'reverse adversarial catalog');
  await Promise.all([compare(a, 'concurrent root A'), compare(b, 'concurrent root B')]);
  await set(a, [['changed root A', S({ type: 'string' }), 'fresh']]);
  await compare(a, 'schema/catalog replacement between calls');
  await write(a, 'data/0.json', 42);
  await compare(a, 'document-only mutation between calls');
  await compare(b, 'unchanged other root after mutation');
  console.log(JSON.stringify({ verdict: 'pass', candidate: expected, baseline: 'd3892f6b018c006c28d6cf13590548fed9561f53', node: process.version, platform: process.platform, arch: process.arch, case_count: cases.length, labels: cases.map(c => c[0]), comparisons: observations }, null, 2));
} finally { await Promise.all(roots.map(r => fs.rm(r, { recursive: true, force: true }))); }
