import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
const repo='/Users/REDACTED/Documents/ChatGPT/temple-ai-dev-org';
const temporary=await fs.mkdtemp(path.join(os.tmpdir(),'temple-schema-measure-'));
const root=path.join(temporary,'project'),samples=[];
try {
 const init=spawnSync(process.execPath,[path.join(repo,'bin/temple.mjs'),'init',root,'--config',path.join(repo,'docs/getting-started/temple-init.example.json'),'--json'],{cwd:repo,encoding:'utf8',timeout:15000});
 assert.equal(init.status,0,init.stderr);assert.equal(JSON.parse(init.stdout).doctor.healthy,true);
 const sequence=['baseline','candidate','candidate','baseline','baseline','candidate','candidate','baseline'];
 for(const [index,arm] of sequence.entries()){
  const out=path.join(temporary,`sample-${index}.json`);
  const module=arm==='baseline'?'/tmp/wi0241-baseline-doctor.mjs':path.join(repo,'src/doctor.mjs');
  const start=performance.now();
  const r=spawnSync(process.execPath,['--expose-gc','/tmp/wi0241-memory-driver.mjs',module,root,out],{cwd:repo,encoding:'utf8',timeout:30000});
  assert.equal(r.status,0,r.stderr);
  const sample={index,arm,process_elapsed_ms:performance.now()-start,...JSON.parse(await fs.readFile(out,'utf8'))};samples.push(sample);
  console.log(JSON.stringify({index,arm,first_doctor_ms:sample.rounds[0].elapsed_ms,peak_rss_mib:sample.peak_rss_kib/1024,last_gc_heap_mib:sample.rounds.at(-1).after_gc.heapUsed/1024**2}));
 }
 assert.equal(new Set(samples.flatMap(s=>s.rounds.map(r=>r.check_digest))).size,1);
}finally{
 await fs.rm(temporary,{recursive:true,force:true});
 await fs.writeFile('/tmp/wi0241-memory-results.json',JSON.stringify({baseline:'d3892f6b018c006c28d6cf13590548fed9561f53',candidate:spawnSync('git',['rev-parse','HEAD'],{cwd:repo,encoding:'utf8'}).stdout.trim(),method:'Eight alternating fresh processes, five real Doctor calls each on one read-only synthetic fixture; explicit GC only after each timed call. Peak RSS is per process, not application footprint. No historical workstation peak inferred.',samples},null,2)+'\n');
}
