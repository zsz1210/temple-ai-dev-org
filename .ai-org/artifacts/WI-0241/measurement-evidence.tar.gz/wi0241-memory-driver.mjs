import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
const [modulePath,root,resultPath]=process.argv.slice(2);
const importStart=performance.now();
const {runDoctor}=await import(modulePath);
const import_ms=performance.now()-importStart;
const before=process.memoryUsage(), rounds=[];
for(let i=0;i<5;i++){
 const start=performance.now(),report=await runDoctor(root);
 const elapsed_ms=performance.now()-start;
 assert.equal(report.healthy,true);
 const check_digest=createHash('sha256').update(JSON.stringify(report.checks)).digest('hex');
 const after=process.memoryUsage();global.gc();
 rounds.push({elapsed_ms,check_digest,after,after_gc:process.memoryUsage()});
}
await fs.writeFile(resultPath,JSON.stringify({node:process.version,import_ms,before,rounds,peak_rss_kib:process.resourceUsage().maxRSS},null,2)+'\n');
