import subprocess,time,json,pathlib,sys
repo='/Users/REDACTED/Documents/ChatGPT/temple-ai-dev-org'
prefix=pathlib.Path('/tmp/wi0241-full')
samples=[]
def rows():
    result=subprocess.run(['ps','-axo','pid=,ppid=,rss=,comm='],capture_output=True,text=True,check=True)
    return [line.split(None,3) for line in result.stdout.splitlines() if line.strip()]
def descendants(root,table):
    selected={root}
    while True:
        more={int(p) for p,pp,rss,comm in table if int(pp) in selected}
        if more<=selected:break
        selected|=more
    return [{'pid':int(p),'ppid':int(pp),'rss_kib':int(rss),'program':pathlib.Path(comm).name} for p,pp,rss,comm in table if int(p) in selected]
start=time.monotonic()
with prefix.with_suffix('.log').open('w') as log:
    process=subprocess.Popen(['npm','run','verify'],cwd=repo,stdout=log,stderr=subprocess.STDOUT)
    while process.poll() is None:
        own=descendants(process.pid,rows())
        samples.append({'elapsed_s':time.monotonic()-start,'processes':own,'rss_sum_kib':sum(p['rss_kib'] for p in own)})
        time.sleep(1)
    code=process.wait()
summary={'exit_code':code,'elapsed_s':time.monotonic()-start,'sample_interval_s':1,'root_pid':process.pid,'max_process_count':max(len(s['processes']) for s in samples),'sampled_peak_rss_sum_kib':max(s['rss_sum_kib'] for s in samples),'method':'Owned npm verify process and descendants only. RSS sum can double-count shared pages, miss sub-second peaks, and excludes swapped/compressed/GPU allocations; not application footprint. Original full verification and concurrency unchanged.','samples':samples}
prefix.with_suffix('.memory.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='samples'}),flush=True)
sys.exit(code)
