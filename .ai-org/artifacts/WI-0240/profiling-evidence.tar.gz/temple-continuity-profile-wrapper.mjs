import fs from 'node:fs/promises';
import cp from 'node:child_process';
import { syncBuiltinESMExports } from 'node:module';
import { AsyncLocalStorage } from 'node:async_hooks';
import { after } from 'node:test';
const context = new AsyncLocalStorage(), functions = [], operations = new Map();
const originalSpawn = cp.spawnSync, originalCopy = fs.cp, originalWrite = fs.writeFile;
const started = performance.now();
function record(kind, detail, duration, failed = false) {
  const phase = context.getStore() ?? 'test-body-and-cleanup';
  const key = JSON.stringify([phase, kind, detail]);
  let row = operations.get(key);
  if (!row) operations.set(key, row = {phase, kind, detail, calls:0, elapsed_ms:0, failures:0});
  row.calls++; row.elapsed_ms += duration; row.failures += Number(failed);
}
cp.spawnSync = function(binary, args = [], options) {
  let detail;
  if (binary === 'git') {
    const index = args[0] === '-c' ? 4 : 0;
    const command = args[index];
    detail = command === 'show' ? (options?.encoding ? 'git show text/records' : 'git show binary/file-by-file') : `git ${command}`;
  } else if (String(args[0]).endsWith('templew.mjs') || String(args[0]).endsWith('/bin/temple.mjs')) {
    detail = `temple ${args[1]}${args[1] === 'work-item' || args[1] === 'context' ? ' ' + args[2] : ''}`;
  } else detail = args[0] === '--test' ? 'node product tests' : args[0] === '--input-type=module' ? 'node oracle' : 'other process';
  const start = performance.now();
  let result;
  try { result = originalSpawn.call(this, binary, args, options); return result; }
  finally { record('spawnSync', detail, performance.now()-start, result?.status !== 0); }
};
fs.cp = async function(source, destination, options) {
  const start = performance.now();
  let failed = true;
  try { const value = await originalCopy.call(this, source, destination, options); failed = false; return value; }
  finally { record('fs.cp', String(source).endsWith('/node_modules') ? 'runtime node_modules' : 'other tree copy', performance.now()-start, failed); }
};
syncBuiltinESMExports();
const actual = await import('<redacted-home>/Documents/ChatGPT/temple-ai-dev-org/scripts/continuity-fixture.mjs');
function instrument(name) {
  return async (...args) => context.run(name, async () => {
    const start = performance.now();
    let outcome = 'rejected';
    try { const value = await actual[name](...args); outcome = value?.passed === false ? 'negative-result' : 'returned'; return value; }
    finally { functions.push({name, elapsed_ms:performance.now()-start, outcome,
      variant:name === 'createContinuityPair' ? args[1] : name === 'assessContinuityCandidate' ? args[2] : null}); }
  });
}
export const createContinuityPair = instrument('createContinuityPair');
export const assessContinuityCandidate = instrument('assessContinuityCandidate');
export const auditContinuityInputs = instrument('auditContinuityInputs');
export const recordContinuityControl = instrument('recordContinuityControl');
export const { referenceQuote, discountSource } = actual;
after(async () => {
  const elapsed_ms = performance.now()-started;
  cp.spawnSync = originalSpawn; fs.cp = originalCopy; syncBuiltinESMExports();
  await originalWrite('/tmp/temple-continuity-profile.json', JSON.stringify({
    source_revision:'860344965b36a95714fd0087f2148b8f2b23d1dd',
    scope:'Direct calls in test process only; nested CLI processes excluded. Function and operation times overlap.',
    elapsed_ms, functions, operations:[...operations.values()]
  }, null, 2)+'\n');
});
