import fs from 'node:fs/promises';
const p = JSON.parse(await fs.readFile('/tmp/wi0240-profile.json','utf8'));
// The executed probe assumed two leading Git -c pairs. baselineMatches uses
// only one, so its real rev-parse calls were labelled --end-of-options.
// Preserve raw observations and correct only this source-confirmed label.
const labelCorrections = p.operations.filter(r=>r.phase==='assessContinuityCandidate' && r.detail==='git --end-of-options').map(r=>({from:r.detail,to:'git rev-parse',calls:r.calls,source:'scripts/continuity-fixture.mjs baselineMatches'}));
p.operations = p.operations.map(r=>r.phase==='assessContinuityCandidate' && r.detail==='git --end-of-options' ? {...r,detail:'git rev-parse'} : r);
const baseline = await fs.readFile('/tmp/temple-continuity-profile.log','utf8');
const measured = await fs.readFile('/tmp/wi0240-profile.log','utf8');
const summary = text => Object.fromEntries([...text.matchAll(/^ℹ (tests|pass|fail|cancelled|skipped|todo|duration_ms) ([\d.]+)$/gm)].map(m=>[m[1],Number(m[2])]));
const phaseMap = new Map();
for(const f of p.functions) {
  if(!phaseMap.has(f.name))phaseMap.set(f.name,{phase:f.name,calls:0,elapsed_ms:0,outcomes:{}});
  const r=phaseMap.get(f.name);r.calls++;r.elapsed_ms+=f.elapsed_ms;r.outcomes[f.outcome]=(r.outcomes[f.outcome]??0)+1;
}
const phases=[...phaseMap.values()].sort((a,b)=>b.elapsed_ms-a.elapsed_ms);
const commandMap=new Map();
for(const row of p.operations) {
  const key=row.kind+': '+row.detail;
  if(!commandMap.has(key))commandMap.set(key,{kind:row.kind,detail:row.detail,calls:0,elapsed_ms:0,failures:0});
  const r=commandMap.get(key);r.calls+=row.calls;r.elapsed_ms+=row.elapsed_ms;r.failures+=row.failures;
}
const commands=[...commandMap.values()].sort((a,b)=>b.elapsed_ms-a.elapsed_ms);
const data={source_revision:p.source_revision,labelCorrections,baseline:summary(baseline),instrumented:summary(measured),
  wrapper_elapsed_ms:p.elapsed_ms,phases,
  outside_wrapped_functions_ms:p.elapsed_ms-phases.reduce((s,r)=>s+r.elapsed_ms,0),commands,
  spawn_total:commands.filter(x=>x.kind==='spawnSync').reduce((s,r)=>({calls:s.calls+r.calls,elapsed_ms:s.elapsed_ms+r.elapsed_ms}),{calls:0,elapsed_ms:0}),
  assessment_commands:p.operations.filter(x=>x.phase==='assessContinuityCandidate').sort((a,b)=>b.elapsed_ms-a.elapsed_ms),
  interpretation:'Phase times include child operations; do not add the two tables. Failures include expected negative controls. Direct child counts exclude nested CLI subprocesses. The candidate applies bounded Git blob batching; the retained profiler does not mutate source. Timing differences include environmental variation.'};
await fs.writeFile('/tmp/wi0240-summary.json',JSON.stringify(data,null,2)+'\n');
console.log(JSON.stringify(data,null,2));
