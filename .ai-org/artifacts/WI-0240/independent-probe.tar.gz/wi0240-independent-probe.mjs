import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import { chmodSync } from 'node:fs';
import cp from 'node:child_process';
import { syncBuiltinESMExports } from 'node:module';
import os from 'node:os';
import path from 'node:path';
import { createContinuityPair, assessContinuityCandidate, referenceQuote } from '/Users/zsz1210/Documents/ChatGPT/temple-ai-dev-org/scripts/continuity-fixture.mjs';
import { subprocessEnvironment } from '/Users/zsz1210/Documents/ChatGPT/temple-ai-dev-org/scripts/delivery-control-pair.mjs';

const candidate='2d4c018cacde20072c2deba738117da689ad9ce3';
const source='/Users/zsz1210/Documents/ChatGPT/temple-ai-dev-org';
const originalSpawn=cp.spawnSync;
const env=subprocessEnvironment();
function git(root,args) {
  const result=originalSpawn('git',args,{cwd:root,env,encoding:'utf8'});
  assert.equal(result.status,0,result.stderr);return result.stdout.trim();
}
assert.equal(git(source,['rev-parse','HEAD']),candidate);
const temporary=await fs.mkdtemp(path.join(os.tmpdir(),'wi0240-independent-'));
const results=[];
try {
  const pair=await createContinuityPair(path.join(temporary,'pair'),'stable');
  const root=pair.arms.ordinary.root;
  await fs.mkdir(path.join(root,'protected'));
  for(let index=0;index<20;index++)await fs.writeFile(path.join(root,`protected/${index}.bin`),Buffer.from([0,255,index,10]));
  git(root,['add','.']);git(root,['commit','-m','Independent protected inputs']);
  pair.arms.ordinary.baseline=git(root,['rev-parse','HEAD']);
  pair.arms.ordinary.tree={};
  for(const row of git(root,['ls-tree','-r','-z','HEAD']).split('\0').filter(Boolean)) {
    const [meta,file]=row.split('\t');const [mode,,oid]=meta.split(' ');
    pair.arms.ordinary.tree[file]={mode,oid};
  }
  await fs.writeFile(path.join(root,'quote.mjs'),referenceQuote(pair.threshold));
  git(root,['add','quote.mjs']);git(root,['commit','-m','Independent accepted product']);
  const revision=git(root,['rev-parse','HEAD']);
  const scratchParent=path.join(temporary,'scratch');await fs.mkdir(scratchParent);
  let executions=0;
  for(const fault of ['second-disk-batch','mode-after-batch','extraction-truncated']) {
    let batches=0,injected=false;
    cp.spawnSync=(binary,args,options)=>{
      const result=originalSpawn(binary,args,options);
      if(binary==='git'&&args[0]==='cat-file') {
        batches++;
        const extraction=options.maxBuffer<1024*1024;
        if(fault==='second-disk-batch'&&batches===2&&!extraction) {
          injected=true;
          return {...result,stdout:Buffer.concat([result.stdout,Buffer.from('unexpected-tail')])};
        }
        if(fault==='mode-after-batch'&&!injected&&options.input.split('\n').includes(pair.arms.ordinary.tree['HANDOFF.md'].oid)) {
          injected=true;chmodSync(path.join(root,'HANDOFF.md'),0o755);
        }
        if(fault==='extraction-truncated'&&extraction) {
          injected=true;return {...result,stdout:result.stdout.subarray(0,-1)};
        }
      }
      return result;
    };
    syncBuiltinESMExports();
    try {
      const expected=fault==='mode-after-batch'?'unsafe-working-file':fault==='extraction-truncated'?'unreadable-candidate':'dirty-source';
      await assert.rejects(()=>assessContinuityCandidate(root,pair,'ordinary',revision,{
        scratchParent,candidateExecutor(){executions++;throw Error('candidate must not execute');}
      }),new RegExp(`^Error: ${expected}$`));
      assert.equal(injected,true,'planned injection reached');
      assert.equal(executions,0,'no partial acceptance can invoke candidate');
      assert.deepEqual(await fs.readdir(scratchParent),[],'owned scratch removed after any failure');
      results.push({fault,rejected_as:expected,batches,executions,remaining_scratch:0});
    } finally {
      cp.spawnSync=originalSpawn;syncBuiltinESMExports();
      await fs.chmod(path.join(root,'HANDOFF.md'),0o644);
    }
  }
  assert.equal((await assessContinuityCandidate(root,pair,'ordinary',revision,{scratchParent})).passed,true);
  assert.deepEqual(await fs.readdir(scratchParent),[]);
  results.push({fault:'restored-control',passed:true,remaining_scratch:0});
  assert.equal(git(source,['rev-parse','HEAD']),candidate);
  console.log(JSON.stringify({candidate,reviewer:'agent-lulu',node:process.version,platform:process.platform,arch:process.arch,results},null,2));
} finally {
  cp.spawnSync=originalSpawn;syncBuiltinESMExports();
  await fs.rm(temporary,{recursive:true,force:true});
}
