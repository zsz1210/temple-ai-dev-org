import fs from 'node:fs/promises';
import path from 'node:path';
import { execFileSync, spawnSync } from 'node:child_process';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';

const repository = '<redacted-home>/Documents/ChatGPT/temple-ai-dev-org';
const root = '/tmp/temple-pruning-final-qa-WBwfqd';
const candidate = '220eda6180c1806d4bc261c9332bf3e55ed92a0b';
const baseline = '477e0b60ecbe83caea18430ccb649c67ecd690ca';
const gitSource = (revision, file) => execFileSync('git', ['show', `${revision}:${file}`], { cwd: repository, encoding: 'utf8' });
const browser = gitSource(candidate, 'scripts/verify-console-browser.mjs');
const viewportPattern = /export const CONSOLE_VIEWPORTS = Object\.freeze\(\[[\s\S]*?\]\);/;
const viewsPattern = /export const PRIMARY_VIEWS = Object\.freeze\(\[[\s\S]*?\]\);/;
const harmless = browser.replace(viewportPattern, `export const CONSOLE_VIEWPORTS = Object.freeze([
  Object.freeze({name: "desktop", width: 1366, height: 900}),
  Object.freeze({name: "mobile", width: 412, height: 915}),
  Object.freeze({name: "ultrawide", width: 2560, height: 1200}),
  Object.freeze({name: "tablet", width: 820, height: 1180}),
  Object.freeze({name: "extra", width: 2000, height: 900})
]);`).replace(viewsPattern, `export const PRIMARY_VIEWS = Object.freeze([
  Object.freeze({target: "history", label: "Past activity"}),
  Object.freeze({target: "organization", label: "People"}),
  Object.freeze({target: "now", label: "Today"}),
  Object.freeze({target: "execution", label: "Execution"}),
  Object.freeze({target: "system", label: "Settings"}),
  Object.freeze({target: "usage", label: "Consumption"})
]);`);
const cases = [
  ['unchanged', browser, candidate, 0],
  ['empty-viewports', browser.replace(viewportPattern, 'export const CONSOLE_VIEWPORTS = Object.freeze([]);'), candidate, 1],
  ['omitted-organization', browser.replace('  Object.freeze({ target: "organization", label: "Team" }),\n', ''), candidate, 1],
  ['omitted-tablet', browser.replace('  Object.freeze({ name: "tablet", width: 768, height: 1024 }),\n', ''), candidate, 1],
  ['invalid-height', browser.replace('width: 390, height: 844', 'width: 390, height: 0'), candidate, 1],
  ['same-width-classes', browser.replace('width: 1440, height: 1000', 'width: 768, height: 1000'), candidate, 1],
  ['lost-mobile-breakpoint', browser.replace('width: 390, height: 844', 'width: 760, height: 844'), candidate, 1],
  ['harmless-pixels-labels-order-extra', harmless, candidate, 0],
  ['baseline-harmless-pixels-labels-order-extra', harmless, baseline, 1]
];
const observations = [];
for (const [name, source, revision, expected] of cases) {
  if (name !== 'unchanged') assert.notEqual(source, browser);
  const fixture = path.join(root, name);
  await fs.mkdir(path.join(fixture, 'scripts'), {recursive:true});
  await fs.mkdir(path.join(fixture, 'test'), {recursive:true});
  for (const entry of ['src','node_modules','package.json','package-lock.json','THIRD_PARTY_NOTICES.md']) {
    await fs.symlink(path.join(repository, entry), path.join(fixture, entry));
  }
  await fs.writeFile(path.join(fixture,'scripts/verify-console-browser.mjs'), source);
  const testPath = path.join(fixture,'test/console-browser-contract.test.mjs');
  await fs.writeFile(testPath, gitSource(revision,'test/console-browser-contract.test.mjs'));
  const run = spawnSync(process.execPath, ['--test','--test-reporter=tap',testPath], {cwd:fixture, encoding:'utf8'});
  const log = `${run.stdout}${run.stderr}`;
  await fs.writeFile(path.join(root,`${name}.tap`),log);
  observations.push({name,revision,expected,exit:run.status,summary:log.split('\n').filter(s=>/^# (tests|pass|fail|cancelled|skipped|todo|duration_ms)/.test(s)),failures:log.split('\n').filter(s=>/^not ok/.test(s)),log_sha256:createHash('sha256').update(log).digest('hex')});
  assert.equal(run.status,expected,name);
  assert.match(log,/# tests 5\n/);
  assert.match(log,/# skipped 0\n/);
  if(expected===1) assert.match(log,/# fail 1\n/);
}
await fs.writeFile(path.join(root,'results.json'),JSON.stringify({reviewer:'agent-lulu',principal:'human',runtime:'/root/pruning_final_review',candidate,baseline,node:process.version,node_path:process.execPath,platform:process.platform,arch:process.arch,observations},null,2));
console.log(JSON.stringify(observations,null,2));
