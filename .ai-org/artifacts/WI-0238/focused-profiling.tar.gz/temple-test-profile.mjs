import child from 'node:child_process';
import fs from 'node:fs';
import promises from 'node:fs/promises';
import { syncBuiltinESMExports } from 'node:module';
import { promisify } from 'node:util';
import path from 'node:path';
import crypto from 'node:crypto';
const originalRandomInt=crypto.randomInt;
crypto.randomInt=function(...args){
 if(process.env.TEMPLE_TEST_PROFILE_ORDER==='temple-first' && args.length===1 && args[0]===2) return 0;
 return originalRandomInt.apply(this,args);
};
const start=performance.now(), totals={};
const record=(name,elapsed)=>{ const v=totals[name]??={count:0,elapsed_ms:0}; v.count++;v.elapsed_ms+=elapsed; };
for(const name of ['cp','readFile','readdir']) {
 const original=promises[name];
 promises[name]=async function(...args){const t=performance.now();try{return await original.apply(this,args);}finally{record('fs.'+name,performance.now()-t);}};
}
const original=child.execFile;
child.execFile=function(program,...args){
 const t=performance.now(), callback=args.pop();
 const argv=Array.isArray(args[0])?args[0]:[];
 let key=path.basename(program);
 if(key==='zsh') {
   const inner=argv.at(-1)??'';
   key+=':'+ (inner.includes('templew.mjs')?'temple:'+ (inner.match(/templew\.mjs['"]?\s+['"]?([^'"\s]+)/)?.[1]??'unknown'):inner.includes('node --test')?'product-tests':inner.match(/^'?([^'\s]+)/)?.[1]??'other');
 } else if(key==='node') key+=':'+path.basename(argv[0]??'')+':'+(argv[1]??'');
 else if(key==='git') key+=':'+(argv[0]??'');
 return original.call(this,program,...args,(...result)=>{record(key,performance.now()-t);callback(...result);});
};
child.execFile[promisify.custom]=function(...args){return new Promise((resolve,reject)=>child.execFile(...args,(error,stdout,stderr)=>{if(error){error.stdout=stdout;error.stderr=stderr;reject(error);}else resolve({stdout,stderr});}));};
syncBuiltinESMExports();
process.on('exit',()=>{
 const dir=process.env.TEMPLE_TEST_PROFILE_DIR;
 if(dir){fs.mkdirSync(dir,{recursive:true});fs.writeFileSync(path.join(dir,`${process.pid}.json`),JSON.stringify({pid:process.pid,node:process.version,order:process.env.TEMPLE_TEST_PROFILE_ORDER??'uncontrolled',elapsed_ms:performance.now()-start,totals},null,2)+'\n');}
});
