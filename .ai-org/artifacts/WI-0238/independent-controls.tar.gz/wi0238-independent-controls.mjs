import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
const source=await fs.readFile('<redacted-home>/Documents/ChatGPT/temple-ai-dev-org/test/delivery-control-pair.test.mjs','utf8');
const helper=source.slice(source.indexOf('  const initialPairs ='),source.indexOf('  async function run(options'));
const body=source.slice(source.indexOf('    for (const order',source.indexOf('await t.test("initial pair copies')),source.indexOf('  await t.test("broken actual product')).replace(/  \}\);\s*$/,'');
const AsyncFunction=Object.getPrototypeOf(async function(){}).constructor;
const results=[];
async function linkedCopy(from,to){
  await fs.mkdir(to,{recursive:true});
  for(const entry of await fs.readdir(from,{withFileTypes:true})){
    if(entry.isDirectory())await linkedCopy(path.join(from,entry.name),path.join(to,entry.name));
    else await fs.link(path.join(from,entry.name),path.join(to,entry.name));
  }
}
for(const mode of ['actual','wrong-key','hardlinks','directory-alias']){
 const parent=await fs.mkdtemp(path.join(os.tmpdir(),'wi0238-qa-'));
 let preparations=0;
 const preparePair=async({labRoot,order})=>{
  preparations++;
  const manifest={order:[...order],arms:Object.fromEntries(order.map((name,index)=>[name,{id:`arm-${index}`}]))};
  for(const name of [path.join(manifest.arms.ordinary.id,'order.mjs'),path.join(manifest.arms.temple.id,'.ai-org/work-items/WI-0001.json'),path.join(manifest.arms.temple.id,'.git/config')]){
   await fs.mkdir(path.dirname(path.join(labRoot,name)),{recursive:true});await fs.writeFile(path.join(labRoot,name),`pristine ${order.join('/')} ${name}`);
  }
  await fs.writeFile(path.join(labRoot,'manifest.json'),JSON.stringify(manifest));return manifest;
 };
 const template=path.join(parent,'template');
 const manifest=await preparePair({labRoot:template,order:['temple','ordinary']});
 const api={...fs};
 if(mode==='hardlinks')api.cp=linkedCopy;
 if(mode==='directory-alias')api.cp=(from,to)=>fs.symlink(from,to,'dir');
 let code=helper;
 if(mode==='wrong-key')code=code.replace('const key = JSON.stringify(order);','const key = JSON.stringify(manifest.order);');
 const extra=`
 const copy=path.join(parent,'extra');
 const returned=await copyInitialPair(copy);
 assert.deepEqual(JSON.parse(await fs.readFile(path.join(copy,'manifest.json'),'utf8')),returned);
 assert.deepEqual(returned.order,manifest.order);
 `;
 try{
  await new AsyncFunction('fs','path','assert','parent','template','manifest','preparePair','sourceRoot',code+body+extra)(api,path,assert,parent,template,manifest,preparePair,parent);
  results.push({mode,outcome:'pass',preparations});
 }catch(error){results.push({mode,outcome:'rejected',preparations,code:error.code,message:error.message.slice(0,220)});}
 finally{await fs.rm(parent,{recursive:true,force:true});}
}
assert.equal(results[0].outcome,'pass');assert.equal(results[0].preparations,2);
for(const result of results.slice(1))assert.equal(result.outcome,'rejected');
console.log(JSON.stringify({node:process.version,platform:`${process.platform}/${process.arch}`,source_sha256:createHash('sha256').update(source).digest('hex'),results,cleanup:'all disposable fixture directories removed'},null,2));
